var struct_t_p3_1_1_chemin =
[
    [ "coutTotal", "struct_t_p3_1_1_chemin.html#ad9a9c179c97594d38f02f1b1d8fae61d", null ],
    [ "dureeTotale", "struct_t_p3_1_1_chemin.html#ad7312a49ca0a4f1573aa50b7816941d6", null ],
    [ "listeVilles", "struct_t_p3_1_1_chemin.html#a11408a1eb1ca7d72c77971685af3d7ab", null ],
    [ "nsTotal", "struct_t_p3_1_1_chemin.html#a058f243a4353d3b7466da2d4ec91b9ff", null ],
    [ "reussi", "struct_t_p3_1_1_chemin.html#a3651bd95d65f03ec741f9e5767f89885", null ]
];