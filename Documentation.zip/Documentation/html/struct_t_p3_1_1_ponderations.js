var struct_t_p3_1_1_ponderations =
[
    [ "cout", "struct_t_p3_1_1_ponderations.html#a6f781b3f0324fcb882d76ec0b7f2f1e2", null ],
    [ "duree", "struct_t_p3_1_1_ponderations.html#aedca132c24fc5a30b178ee4fde5615a0", null ],
    [ "ns", "struct_t_p3_1_1_ponderations.html#aa656627754583ab3f984fdb97b8eb10f", null ]
];